palindrom = int(input("Введите число: "))
# while palindrom > 0:
if palindrom // 10 > 0:
    print(palindrom % 10)
if palindrom // 100 > 0:
    print(((palindrom % 10) // 10) % 10)
if palindrom // 1000 > 0:
    print(((((palindrom % 10) // 10) % 10) // 10) % 10)
if palindrom // 10000 > 0:
    print(((((((palindrom % 10) // 10) % 10) // 10) % 10) // 10) % 10)
if palindrom // 100000 > 0:
    print(((((((((palindrom % 10) // 10) % 10) // 10) % 10) // 10) % 10) // 10) % 10)
