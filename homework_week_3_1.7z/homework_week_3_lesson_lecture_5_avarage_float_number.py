num_float_nam = int(input("Введите количество чисел последовательности: "))
avarage = 0
number = 1
min = 9 ** 100
max = -9 ** 100
while num_float_nam > 0:
    float_nam = float(input("Введите число: "))
    avarage += float_nam
    avarage /= number
    if float_nam < min:
        min = float_nam
    if float_nam > max:
        max = float_nam
    num_float_nam -= 1
    number += 1
print("Количество чисел: %d" % (number - 1))
print("Среднее арифметическое: %f" % avarage)
print("Минимальное чсисло: {0}".format(min))
print("Максимальное число: %f" % max)
